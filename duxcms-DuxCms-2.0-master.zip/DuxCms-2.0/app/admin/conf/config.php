<?php
return array(
	//'配置项'=>'配置值'
	'APP_SYSTEM' => 1,
	'APP_NAME' => '公共后台',
);