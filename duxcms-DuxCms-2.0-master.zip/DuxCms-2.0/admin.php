<?php
define('ADMIN_STATUS',true);
require( 'framework/core.php' );