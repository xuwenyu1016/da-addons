<?php

namespace app\hejiang;

class SentryHandler extends \Raven_ErrorHandler
{
    
}