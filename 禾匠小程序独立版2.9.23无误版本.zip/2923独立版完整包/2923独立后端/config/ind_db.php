<?php
defined('IN_IA') or define('IN_IA', true);
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;port=3306;dbname=h_weixin2015_cn',
    'username' => 'h_weixin2015_cn',
    'password' => 'weimao',
    'charset' => 'utf8',
    'tablePrefix' => 'hjmallind_',
];