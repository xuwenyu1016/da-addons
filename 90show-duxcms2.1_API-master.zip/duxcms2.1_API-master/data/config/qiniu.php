<?php
/**
 * @Author: 王斌
 * @Date:   2017-08-05 11:31:40
 * @Last Modified by:   王斌
 * @Last Modified time: 2017-08-19 18:42:12
 */
return array(
    /* 七牛设置 */
    'QINIU_STATUS'=>false,//是否开启七牛云上传
    'QINIU_AK'=>'',//AccessKey
    'QINIU_SK'=>'',//SecretKey
    'QINIU_BUCKET'=>'',//bucketn
    'QINIU_URL'=>'http://*****.bkt.clouddn.com/',//七牛分配给你的url或者你自己绑定的url

);