<?php
return array(
    /* 版本信息请勿更改 */
    'DUX_VER'   => '2.1.0',
    'DUX_TIME'   => '20150202',
);