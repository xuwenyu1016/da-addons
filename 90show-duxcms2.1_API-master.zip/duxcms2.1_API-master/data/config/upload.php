<?php
return array(
    /* 上传设置 */
    'UPLOAD_SIZE'=>10,
    'UPLOAD_EXTS'=>'jpg,gif,bmp,png',
    'THUMB_STATUS'=>0,
    'THUMB_TYPE'=>1,
    'THUMB_WIDTH'=>800,
    'THUMB_HEIGHT'=>800,
    'WATER_STATUS'=>0,
    'WATER_IMAGE'=>'logo.jpg',
    'WATER_POSITION'=>1,
);