<?php
/* 性能设置 */
return array (
	'DEBUG'=>false,	//是否开启调试模式
	'LOG_ON'=>true,	//是否开启出错信息保存到文件
	'API_ON'=>false,	//api开关
	'REWRITE_ON'=>true,	//伪静态开关
	'COOKIE_PREFIX'=>'I1V0I_', // COOKIE前缀
    'SAFE_KEY'=>'flRyXUr6pM3348Q2Ln5v', // 加密码
    'API_TOKEN'=>'DdWtkX6NqPSZdMkLD6sJMVU42', // 加密码

);