<?php
return array (
	//默认模块
	'DEFAULT_APP' => 'page',
	'DEFAULT_CONTROLLER' => 'Info',
	'DEFAULT_ACTION' => 'index',
	'DEBUG'=>true,	//是否开启调试模式
	'REWRITE_ON'=>false,	//伪静态开关
	);