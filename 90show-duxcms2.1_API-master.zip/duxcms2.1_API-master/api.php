<?php
define('LYAER_NAME','Api');
require( 'framework/core.php' );