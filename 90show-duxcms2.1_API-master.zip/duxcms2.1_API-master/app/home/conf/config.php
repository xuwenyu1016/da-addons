<?php
return array(
	//'配置项'=>'配置值'
	'APP_SYSTEM' => true,
	'APP_NAME' => '前台基础类',
);