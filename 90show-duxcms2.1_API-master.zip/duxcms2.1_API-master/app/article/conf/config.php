<?php
return array(
	//'配置项'=>'配置值'
	'APP_STATE'=>true,
	'APP_INSTALL'=> true,
	'APP_NAME'=> '文章系统',
	'APP_SETTING' => 'article/AdminSetting/index',
	'ARTICLE_TOPIC'=>1,
	'ARTICLE_DESCRIPTION'=>1,
	'ARTICLE_TAGLINK'=>1,
	'ARTICLE_COPYFROM'=>'本站,duxcms',
	'ARTICLE_CLASS_TPL'=>'list',
	'ARTICLE_CONTENT_TEL'=>'content',
	'ARTICLE_PAGE'=>10,
);