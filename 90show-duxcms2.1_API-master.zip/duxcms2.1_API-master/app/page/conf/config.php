<?php 
return array (
  'APP_STATE'=>true,
  'APP_INSTALL' => true,
  'APP_NAME' => '单页系统',
);