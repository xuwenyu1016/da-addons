<?php
namespace app\duxcms\model;
use app\base\model\BaseModel;
/**
 * 更新操作
 */
class UpdateModel extends BaseModel {

}
