#####微信公众号开发js-sdk配置
* * *
######1.使用的微信公众平台，申请的测试账号。
######2.使用了thinkphp框架。
######3.若直接使用源码，需要修改 appID ，appsecret 参数。
######4.测试结果：
        {"errMsg":"config：ok"}
        
* * *
######目录介绍：
    application(应用目录)
     |——wechat（模块）
          |——controller（控制器目录）
          |    |——Samplp.php 
          |——view（视图目录）
              |——sample
                  |——index.html
        