<?php
namespace  app\wechat\controller;

use think\Controller;

class Sample extends Controller
{
    public function index()
    {
        // 获取 jsapiticket
        $jsapi_ticket = $this->getJsApiTicket();
        // 签名的时间戳
        $time = time();
        // 签名的字符串
        $noncestr = $this->getRandomCode();
        
        // 注意 URL 一定要动态获取，不能 hardcode.
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        // 签名
        $signature = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$time&url=$url";
        // 加密
        $signature = sha1($signature);
        
        return view('index',[
            "time"         => $time,
            "noncestr"     => $noncestr,
            "signature"    => $signature,
        ]);
    }
    
    /*
     * 获取一个随机16位字符串
     */
    public function getRandomCode()
    {
        $arr = array_merge(range("a", "z"),range("A", "Z"),range(0, 9));
        shuffle($arr);
        $str = substr(join("", $arr), mt_rand(0,12),16);
        return $str;
    }
    
    /*
     * 获取jsapi_ticket票据，并设置生命期
     */
    public function getJsApiTicket()
    {
        if(session('jsapi_ticket_expire_time') > time() && session('jsapi_ticket_expire_time')){
            $jsapi_ticket = session('jsapi_ticket');
        }else{
            // 获取access_token
            $access_token = $this->get_access_token();
            $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=$access_token&type=jsapi";
            $arr = $this->CurlGet($url);
            // 得到jsapiticket
            $jsapi_ticket = $arr['ticket'];
            session('jsapi_ticket',$jsapi_ticket);
            // 设置生命期
            session('jsapi_ticket_expire_time',time()+7000);
        }
        return $jsapi_ticket;
    }
    
    /*
     * 获取access_token的，设置生命期。
     */
    public function get_access_token(){
        // 判断是否过期
        if( session('access_token') && session('expire_access_token') > time()){
            $access_token = session('access_token');
        }else{
            // 过期，重新获取
            $url = "https://api.weixin.qq.com/cgi-bin/token";
            $data = array(
                "grant_type"=>"client_credential",
                "appid"=>"你的appid",
                "secret"=>"你的secret"
            );
            $url =$url."?".http_build_query($data);
            $arr = $this->CurlGet($url);
            $access_token = $arr['access_token'];
            session('access_token',$access_token);
            // 设置生命期
            session('expire_access_token',time() + 7000);
        }
        return $access_token;
    }
    
    /*
     * curl的get请求。
     */
    public function CurlGet($url){
        // 1.初始化
        $ch = curl_init();
        // 2.设置参数
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // 3.执行
        $mes = curl_exec($ch);
        // 判断错误
        if( curl_error($ch)){
            var_dump(curl_error($ch));
        }
        // 4.关闭
        curl_close($ch);
        // 处理json数据，返回一个数组。
        $arr = json_decode($mes,true);
        return $arr;
    }
}
