<?php
class content_indexModel extends commonModel
{
    public function __construct()
    {
        parent::__construct();
    }

}

?>