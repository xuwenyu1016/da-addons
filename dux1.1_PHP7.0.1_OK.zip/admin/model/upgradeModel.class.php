<?php
//后台首页
class upgradeModel extends commonModel {

	public function __construct()
  {
        parent::__construct();
  }

}