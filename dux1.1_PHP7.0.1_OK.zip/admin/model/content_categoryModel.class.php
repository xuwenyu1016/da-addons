<?php
class content_categoryModel extends commonModel
{
    public function __construct()
    {
        parent::__construct();
    }

    //模型附加表信息
    public function model_ini_data()
    {
        return array(
        );
    }
    //模型文件或文件夹信息
    public function model_ini_file()
    {
        return array(
        );
    }
    
}

?>