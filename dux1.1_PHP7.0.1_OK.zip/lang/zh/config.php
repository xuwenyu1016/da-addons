<?php
$config['sitename']='DUXWEB开源中心,duxcms内容管理系统';
$config['seoname']='免费小巧的网站管理系统';
$config['siteurl']='http://www.duxcms.com';
$config['keywords']='小巧CMS,免费CMS';
$config['description']='DUXCMS是一款基于PHP+MYSQL,采用CANPHP框架编写的一款针对大小型公司企业、政府等通用的开源cms程序。';
$config['masteremail']='admin@dxcms.net';
$config['copyright']='版权信息';