<?php
$config['sitename']='Dux Content Management System';
$config['seoname']='Free and Open Source';
$config['siteurl']='http://www.duxcms.com';
$config['keywords']='Free,Open source';
$config['description']='DUXCMS is a based on PHP + MySQL, a written in CANPHP framework program for large and small businesses, government and other common open source cms.';
$config['masteremail']='admin@dxcms.net';
$config['copyright']='Copyright Information';