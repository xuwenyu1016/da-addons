<?php
$config['DB_TYPE']='mysqli'; //数据库类型，一般不需要修改
$config['DB_HOST']='localhost'; //数据库主机，一般不需要修改
$config['DB_USER']='root'; //数据库用户名
$config['DB_PWD']='root'; //数据库密码
$config['DB_PORT']=3306; //数据库端口，mysql默认是3306，一般不需要修改
$config['DB_NAME']='duxcms'; //数据库名
$config['DB_CHARSET']='utf8'; //数据库编码，一般不需要修改
$config['DB_PREFIX']='dc_'; //数据库前缀
$config['SPOT']='S2USO_';
?>