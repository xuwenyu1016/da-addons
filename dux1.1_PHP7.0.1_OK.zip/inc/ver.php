<?php
$config['ver'] = '1.1.0'; //版本号
$config['ver_name'] = 'DUXCMS 稳定版'; //版本名称
$config['ver_date'] = '20130618'; //版本时间
?>