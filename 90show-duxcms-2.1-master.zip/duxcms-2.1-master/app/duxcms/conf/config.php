<?php
return array(
	//'配置项'=>'配置值'
	'APP_SYSTEM' => true,
	'APP_NAME' => 'DUXCMS基础模块',
);