<?php exit;?>0015229112689e6430c9af4e4af7a5c4bd9f851ec8b7s:2006:"a:2:{s:8:"template";s:1942:"<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">
    <title>DuxCms安装向导</title>
    <link rel="stylesheet" href="/public/common/css/pintuer.css">
    <link rel="stylesheet" href="/public/install/css/style.css">
    <script src="/public/js/jquery.js"></script>
    <script src="/public/common/js/pintuer.js"></script>
    <script src="/public/common/js/respond.js"></script>
    <script src="/public/install/js/install.js"></script>
</head>
<body>
    <div class="container">
        <div class="ins-head">
            <h1>DuxCms 安装程序</h1>
        </div>
        <div class="panel ins-panel">
            <div class="ins-step">
                <div class="step">
                    <div class="step-bar complete" style="width:25%;"><span class="step-point icon-check"></span><span class="step-text">阅读用户协议</span></span>
                    </div>
                    <div class="step-bar complete" style="width:25%;"><span class="step-point icon-check"></span><span class="step-text">检查安装环境</span>
                    </div>
                    <div class="step-bar complete" style="width:25%;"><span class="step-point icon-check"></span><span class="step-text">配置程序信息</span>
                    </div>
                    <div class="step-bar active" style="width:25%;"><span class="step-point">4</span><span class="step-text">完成安装操作</span>
                    </div>
                </div>
            </div>
                <div class="panel-body">
                    <div class="ins-log">
                    </div>
                </div>
                <div class="panel-foot text-center">
                    安装中...
                </div>
        </div>
    </div>
</body>
</html>";s:12:"compile_time";i:1491375268;}";