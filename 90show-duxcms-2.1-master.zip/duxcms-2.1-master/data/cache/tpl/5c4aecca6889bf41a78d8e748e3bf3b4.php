<?php exit;?>001522980806b6dc47e95b88d9e364a8587968cd3a02s:4009:"a:2:{s:8:"template";s:3945:"<form method="post" class="form-x dux-form form-auto" id="form" action="<?php echo url();?>">
    <div class="panel dux-box  active">
        <div class="panel-head">
            <strong>短信接口配置</strong>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <div class="label">
                    <label>是否开启</label>
                </div>
                <div class="field">
                        <div class="button-group button-group-small radio">
                           <?php if(!isset($info['SMS_OPEN'])) $info['SMS_OPEN'] = 1; ?>
                            <?php if ($info['SMS_OPEN']){ ?>
                            <label class="button active"><input name="SMS_OPEN" value="1" checked="checked" type="radio">
                            <?php }else{ ?>
                            <label class="button"><input name="SMS_OPEN" value="1" type="radio">
                            <?php } ?>
                            <span class="icon icon-check"></span> 开启</label>
                            <?php if (!$info['SMS_OPEN']){ ?>
                            <label class="button active"><input name="SMS_OPEN" checked="checked" value="0" type="radio">
                            <?php }else{ ?>
                            <label class="button"><input name="SMS_OPEN" value="0" type="radio">
                            <?php } ?>
                            <span class="icon icon-times"></span> 关闭</label>
                        </div>
                        <div class="input-note">禁用后订单成交后无法给客户发送短信</div>
                    </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>短信模版编号</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="SMS_ID" name="SMS_ID" size="60" datatype="s" value="<?php echo $info["SMS_ID"];?>">
                    <div class="input-note">短信应用模版编号</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>短信签名名称</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="SIGN_NAME" name="SIGN_NAME" size="60" datatype="s" value="<?php echo $info["SIGN_NAME"];?>">
                    <div class="input-note">短信应用签名名称</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>App Key</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="SMS_KEY" name="SMS_KEY" size="60" datatype="s" value="<?php echo $info["SMS_KEY"];?>">
                    <div class="input-note">应用App Key</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>App Secret</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="SMS_SECRET" name="SMS_SECRET" size="60" datatype="s" value="<?php echo $info["SMS_SECRET"];?>">
                    <div class="input-note">应用App Secret</div>
                </div>
            </div>

        </div>

        <div class="panel-foot">
            <div class="form-button">
                <div id="tips"></div>
                <button class="button bg-main" type="submit">保存</button>
                <button class="button bg" type="reset">重置</button>
            </div>
        </div>
    </div>
</form>
<script>
    Do.ready('base', function () {
        $('#form').duxFormPage();
    });
</script>";s:12:"compile_time";i:1491444806;}";