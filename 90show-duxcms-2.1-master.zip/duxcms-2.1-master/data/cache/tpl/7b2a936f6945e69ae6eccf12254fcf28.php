<?php exit;?>001522911564d19d34871b23fa43aa6547fc60223d99s:261:"a:2:{s:8:"template";s:198:"<div class="g-ft">
<?php $echoList = service("duxcms","Label","fragment",array( "app"=>"DuxCms", "label"=>"fragment", "mark"=>"foot"));  echo $echoList; ?>
<p>Copyright © 2011-2014 DuxCms</p></div>";s:12:"compile_time";i:1491375564;}";