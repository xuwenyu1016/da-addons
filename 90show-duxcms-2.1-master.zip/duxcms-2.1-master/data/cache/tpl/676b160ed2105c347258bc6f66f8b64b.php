<?php exit;?>0015229115792f2443a0db8b8b36fcfd497b9bdf2b81s:3585:"a:2:{s:8:"template";s:3521:"<form method="post" class="form-x dux-form form-auto" id="form" action="<?php echo url();?>">
    <div class="panel dux-box  active">
        <div class="panel-head">
            <strong>操作权限 (勾选栏目后才会生效，不选择任何权限为拥有所有权限)</strong>
        </div>
        <div class="panel-body">
            <?php foreach ($MemberPurvew as $key => $list) { ?>
                <div class="form-group">
                    <div class="label">
                        <label><?php echo $list["name"];?></label>
                    </div>
                    <div class="field">
                        <div class="button-group checkbox">
                          <?php if ( in_array($list["class_id"],(array)$MemberPurvewArray) ){ ?>
                          <label class="button active"><input name="base_purview[]" value="<?php echo $list["class_id"];?>" type="checkbox" onchange="change()" checked="checked"><span class="icon icon-check text-green"></span> <span>允许访问</span></label>
                          <?php }else{ ?>
                          <label class="button"><input name="base_purview[]" value="<?php echo $list["class_id"];?>" type="checkbox" ><span class="icon icon-check text-green"></span>  <span>禁止访问</span></label>
                          <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
          </div>
          <div class="panel-head">
            <strong>表单模块</strong>
          </div>
          <div class="panel-body">
            <?php foreach ($form as $key => $list) { ?>
                <div class="form-group">
                    <div class="label">
                        <label><?php echo $list["name"];?></label>
                    </div>
                    <div class="field">
                        <div class="button-group checkbox">
                          <?php if ( in_array($list["table"],(array)$MemberPurvewArray) ){ ?>
                          <label class="button active"><input name="base_purview[]" value="<?php echo $list["table"];?>" type="checkbox" onchange="change()" checked="checked"><span class="icon icon-check text-green"></span> <span>允许访问</span></label>
                          <?php }else{ ?>
                          <label class="button"><input name="base_purview[]" value="<?php echo $list["table"];?>" type="checkbox" ><span class="icon icon-check text-green"></span>  <span>禁止访问</span></label>
                          <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <div class="panel-foot">
            <div class="form-button">
                <div id="tips"></div>
                <input type="hidden" name="group_id" type="hidden" value="<?php echo $info["group_id"];?>">
                <button class="button bg-main" type="submit">保存</button>
                <button class="button bg" type="reset">重置</button>
            </div>
        </div>
    </div>
</form>
<script>
    Do.ready('base', function () {
        $('#form').duxForm();
    });
    $(document).ready(function(){
      $(":checkbox").change(function() {
        if ($(this).is(':checked') == false) {
          $(this).next().next().html('禁止访问');
        }else{
          $(this).next().next().html('允许访问');
        }
      });
    });
</script>";s:12:"compile_time";i:1491375579;}";