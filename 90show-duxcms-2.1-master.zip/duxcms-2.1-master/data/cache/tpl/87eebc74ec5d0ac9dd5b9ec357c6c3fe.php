<?php exit;?>001522916069e64c0a6ae770777c7b286e175cd00dd3s:5692:"a:2:{s:8:"template";s:5628:"<!--[if lte IE 8]>
<script src="/public/js/chart/excanvas.compiled.js"></script>
<![endif]-->
<div class="panel dux-box">
    <div class="panel-head">站点安全检测</div>
    <ul class="list-group">
       <?php if($safeArray['db']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">安全</div>
                <div class="media-body">
                    <strong>数据库弱口令</strong>已通过据数据库密码复杂度验证
                </div>
            </div>
        </li>
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">危险</div>
                <div class="media-body">
                    <strong>数据库弱口令</strong>请及时修改您的数据库密码必须包含：大小写字母数字和特殊符号
                </div>
            </div>
        </li>
        <?php } ?>
        <?php if($safeArray['user']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">安全</div>
                <div class="media-body">
                    <strong>登录密码检测</strong>已通过登录密码复杂度验证
                </div>
            </div>
        </li>  
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">危险</div>
                <div class="media-body">
                    <strong>登录密码检测</strong>请及时修改您的后台默认密码
                </div>
            </div>
        </li>
        <?php } ?>
        <?php if($safeArray['login']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">安全</div>
                <div class="media-body">
                    <strong>后台入口检测</strong>已经重命名后台登录入口文件
                </div>
            </div>
        </li>
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">危险</div>
                <div class="media-body">
                    <strong>后台入口检测</strong>请重命名后台登录入口文件"admin.php"
                </div>
            </div>
        </li>
        <?php } ?>
        <?php if($safeArray['upload']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">安全</div>
                <div class="media-body">
                    <strong>上传设置检测</strong>已经通过非法上传格式设置检测
                </div>
            </div>
        </li>
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">危险</div>
                <div class="media-body">
                    <strong>上传设置检测</strong>上传配置还有非法上传文件
                </div>
            </div>
        </li>
        <?php } ?>
        <?php if($safeArray['install']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">安全</div>
                <div class="media-body">
                    <strong>安装模块删除</strong>已经删除安装模块
                </div>
            </div>
        </li>
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">危险</div>
                <div class="media-body">
                    <strong>安装模块删除</strong>请手动删除网站目录 “app/install”
                </div>
            </div>
        </li>
        <?php } ?>
    </ul>
</div>
<br>
<div class="panel dux-box">
    <div class="panel-head">权限检测</div>
    <ul class="list-group">
       <?php if($checkArray['upload']){ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">正常</div>
                <div class="media-body">
                    <strong>上传目录写入权限</strong>检测上传目录uploads是否拥有写入权限
                </div>
            </div>
        </li>
        <?php }else{ ?>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-red">失败</div>
                <div class="media-body">
                    <strong>上传目录写入权限</strong>请检查网站根目录的uploads文件夹是否有权限读写
                </div>
            </div>
        </li>
        <?php } ?>
    </ul>
</div>
<!--
<br>
<div class="panel dux-box">
    <div class="panel-head">安全工具</div>
    <ul class="list-group">
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">未开始</div>
                <div class="media-body">
                    <strong>BOM清除器</strong>清除模板中的BOM，避免产生未知换行
                </div>
            </div>
        </li>
        <li>
            <div class="media media-x">
                <div class="float-left txt radius-circle bg-green">未开始</div>
                <div class="media-body">
                    <strong>WEB木马扫描</strong>扫描整站代码，防止恶意注入
                </div>
            </div>
        </li>
    </ul>
</div>
-->
";s:12:"compile_time";i:1491380069;}";