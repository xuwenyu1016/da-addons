<?php exit;?>0015229808007cd65df5d64149b8473c804bba2498f3s:3749:"a:2:{s:8:"template";s:3685:"<div class="panel dux-box">
    <div class="table-tools clearfix ">
        <div class="float-left">
            <form method="post" action="<?php echo url();?>">
                <div class="form-inline">
                    <div class="form-group">
                        <div class="field">
                            <input type="text" class="input" id="order_id" name="order_id" size="20" value="<?php echo $orderId;?>" placeholder="订单号">
                        </div>
                    </div>
                    <div class="form-button">
                        <button class="button" type="submit">搜索</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="table-responsive">
        <table id="table" class="table table-hover ">
            <tbody>
                <tr>
                    <th width="50">序号</th>
                    <th width="*">订单号</th>
                    <th width="*">用户</th>
                    <th width="*">联系方式</th>
                    <th width="*">订单金额</th>
                    <th width="*">支付方式</th>
                    <th width="*">支付状态</th>
                    <th width="*">短信通知</th>
                    <th width="100">操作</th>
                </tr>
                <?php foreach ($list as $vo) { ?>
                <tr>
                    <td><?php echo $vo["id"];?></td>
                    <td><?php echo $vo["order_id"];?></td>
                    <td><?php echo $vo["nickname"];?></td>
                    <td><?php echo $vo["phone"];?></td>
                    <td><?php echo $vo["total"];?></td>
                    <?php if ($vo["payway"] == 'alipay'){ ?>
                    <td>支付宝扫码</td>
                    <?php }else{ ?>
                    <td>微信扫码</td>
                    <?php } ?>
                    <td>
                    <?php if ($vo["ispay"]){ ?>
                    <span class="tag bg-green">已支付</span>
                    <?php }else{ ?>
                    <span class="tag bg-red">未支付</span>
                    <?php } ?>
                    </td>
                    <td>
                    <?php if ($vo["ispost"]){ ?>
                    <span class="tag bg-green">已发送</span>
                    <?php }else{ ?>
                    <span class="tag bg-red">未发送</span>
                    <?php } ?>
                    </td>
                    <td>
                        <a class="button bg-blue button-small icon-search js-info" href="javascript:;" url="<?php echo url('info',array('order_id'=>$vo['order_id']));?>" title="查看订单内容"></a>
                        <a class="button bg-red button-small icon-trash-o js-del" href="javascript:;" data="<?php echo $vo["order_id"];?>" title="删除"></a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="panel-foot table-foot clearfix"><?php echo $page;?></div>
</div>
<script>
Do.ready('base',function() {
	$('#table').duxTable({
		deleteUrl: "<?php echo url('del');?>"
	});
});
Do.ready('dialog',function() {
    $('#table').find('.js-info').click(function () {
        $.layer({
            type : 2,
            shade : [0.5 , '#000' , false],
            maxmin: true,
            shadeClose : true,
            border : [!0],
            title : '订单信息',
            area : ['800px', '500px'],
            iframe : {src : $(this).attr('url')}
        });

    });
});
</script>";s:12:"compile_time";i:1491444800;}";