<?php exit;?>001522980801aaa5234fee76c2dda898d60cc5df9c68s:7533:"a:2:{s:8:"template";s:7469:"<form method="post" class="form-x dux-form form-auto" id="form" action="<?php echo url();?>">
    <div class="panel dux-box  active">
        <div class="panel-head">
            <strong>商城参数配置</strong>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <div class="label">
                    <label>是否开启商城</label>
                </div>
                <div class="field">
                        <div class="button-group button-group-small radio">
                           <?php if(!isset($info['ORDER_OPEN'])) $info['ORDER_OPEN'] = 1; ?>
                            <?php if ($info['ORDER_OPEN']){ ?>
                            <label class="button active"><input name="ORDER_OPEN" value="1" checked="checked" type="radio">
                            <?php }else{ ?>
                            <label class="button"><input name="ORDER_OPEN" value="1" type="radio">
                            <?php } ?>
                            <span class="icon icon-check"></span> 开启</label>
                            <?php if (!$info['ORDER_OPEN']){ ?>
                            <label class="button active"><input name="ORDER_OPEN" checked="checked" value="0" type="radio">
                            <?php }else{ ?>
                            <label class="button"><input name="ORDER_OPEN" value="0" type="radio">
                            <?php } ?>
                            <span class="icon icon-times"></span> 关闭</label>
                        </div>
                        <div class="input-note">禁用后将无法使用购物车功能</div>
                    </div>
            </div>
             <div class="form-group">
                <div class="label">
                    <label>会员中心项目</label>
                </div>
                <div class="field">
                <div class="button-group checkbox">
                  <?php foreach ($usercate as $key => $vo) { ?>
                      <?php if (in_array($key,$user_cate)){ ?>
                      <label class="button active"><input name="USER_CATE[]" value="<?php echo $key;?>" type="checkbox" checked="checked"><span class="icon icon-check text-green"></span><?php echo $vo["title"];?></label>
                      <?php }else{ ?>
                      <label class="button"><input name="USER_CATE[]" value="<?php echo $key;?>" type="checkbox" ><span class="icon icon-check text-green"></span> <?php echo $vo["title"];?></label>
                      <?php } ?>
                  <?php } ?>
                </div>
                <div class="input-note">选择前台会员中心开启哪些项目</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>价格字段</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="ORDER_PRICE_FIELD" name="ORDER_PRICE_FIELD" size="60" datatype="s" value="<?php echo $info["ORDER_PRICE_FIELD"];?>">
                    <div class="input-note">扩展字段中的价格字段名称</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>参与栏目</label>
                </div>
                <div class="field">
                <div class="button-group checkbox">
                  <?php foreach ($categoryList as $key => $vo) { ?>
                  <?php if ($vo["type"]<>0){ ?>
                      <?php if (in_array($vo["class_id"],$cate)){ ?>
                      <label class="button active"><input name="ORDER_CATE[]" value="<?php echo $vo["class_id"];?>" type="checkbox" checked="checked"><span class="icon icon-check text-green"></span><?php echo $vo["name"];?></label>
                      <?php }else{ ?>
                      <label class="button"><input name="ORDER_CATE[]" value="<?php echo $vo["class_id"];?>" type="checkbox" ><span class="icon icon-check text-green"></span> <?php echo $vo["name"];?></label>
                      <?php } ?>
                    <?php } ?>
                  <?php } ?>
                </div>
            </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>包邮条件</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="ORDER_FREE" name="ORDER_FREE" size="60" datatype="s" value="<?php echo $info["ORDER_FREE"];?>">
                    <div class="input-note">达到多少金额时包邮,0为不包邮</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>运费</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="ORDER_FREIGHT" name="ORDER_FREIGHT" size="60" datatype="s" value="<?php echo $info["ORDER_FREIGHT"];?>">
                    <div class="input-note">未满足包邮条件时订单结算的时候自动增加运费</div>
                </div>
            </div>
        </div>
        <div class="panel-head">
            <strong>支付接口参数配置</strong>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <div class="label">
                    <label>支付接口URL</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="TEE_API_URL" name="TEE_API_URL" size="60" datatype="*" value="<?php echo $info["PAY_INFO"]["TEE_API_URL"];?>">
                    <div class="input-note">集成的是天工支付接口,申请地址:<a href="https://charging.teegon.com/" target="_blank">https://charging.teegon.com/</a></div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>client_id</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="TEE_CLIENT_ID" name="TEE_CLIENT_ID" size="60" datatype="*" value="<?php echo $info["PAY_INFO"]["TEE_CLIENT_ID"];?>">
                    <div class="input-note">天工接口的client_id</div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label>client_secret</label>
                </div>
                <div class="field">
                    <input type="text" class="input" id="TEE_CLIENT_SECRET" name="TEE_CLIENT_SECRET" size="60" datatype="*" value="<?php echo $info["PAY_INFO"]["TEE_CLIENT_SECRET"];?>">
                    <div class="input-note">天工接口的client_secret</div>
                </div>
            </div>
        </div>
        
        <div class="panel-foot">
            <div class="form-button">
                <div id="tips"></div>
                <button class="button bg-main" type="submit">保存</button>
                <button class="button bg" type="reset">重置</button>
            </div>
        </div>
    </div>
</form>
<script>
    Do.ready('base', function () {
        $('#form').duxFormPage();
    });
</script>";s:12:"compile_time";i:1491444801;}";