<?php
return array(
    /* 数据库配置 */
	'DB_TYPE' => 'mysql',
	'DB_HOST'=>'localhost',
	'DB_USER'=>'demoshow',
	'DB_PWD'=>'demoshow',
	'DB_PORT'=>3306,
	'DB_NAME'=>'demoshow',
	'DB_CHARSET' => 'utf8',
	'DB_PREFIX'=>'dux_',
);