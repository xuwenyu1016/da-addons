<?php 
return array (
	//默认模块
	'DEFAULT_APP' => 'admin',
	'DEFAULT_CONTROLLER' => 'Index',
	'DEFAULT_ACTION' => 'index',
	'DEBUG'=>true,	//是否开启调试模式
	'LOG_ON'=>true,	//是否开启出错信息保存到文件
	'REWRITE_ON'=>false,	//伪静态开关
	);