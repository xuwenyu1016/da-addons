<?php 

/* 性能设置 */

return array (

	'DEBUG'=>true,	//是否开启调试模式

	'LOG_ON'=>true,	//是否开启出错信息保存到文件

	'REWRITE_ON'=>false,	//伪静态开关

	'COOKIE_PREFIX'=>'pkidp_', // COOKIE前缀

    'SAFE_KEY'=>'rPMvGmYSkvZFhV2uTAyG', // 加密码

);