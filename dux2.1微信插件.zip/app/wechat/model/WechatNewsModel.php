<?php
namespace app\wechat\model;
use app\base\model\BaseModel;
/**
 * 图文素材
 */
class WechatNewsModel extends BaseModel {
    protected $_auto = array (
        array('time','strtotime',3,'function'), //时间
     );

    /**
     * 获取粉丝列表
     * @return array 列表
     */
    public function loadList($where = array(), $limit = 0, $order = 'id desc,time desc'){
        //获取最终结果
        $pageList = $this->field($field)
                    ->where($where)
                    ->order($order)
                    ->limit($limit)
                    ->select();
        return $pageList;
    }

    /**
     * 更新信息
     * @param string $type 更新类型
     * @param array $data 更新数据
     * @return bool 更新状态
     */
    public function saveData($type = 'add'){
        $data = $this->create();
        if(!$data){
            return false;
        }
        if($type == 'add'){
            return $this->add($data);
        }
        if($type == 'edit'){
            if(empty($data['id'])){
                return false;
            }
            $where = array();
            $where['id'] = $data['id'];
            $status = $this->where($where)->save($data);
            if($status === false){
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 获取信息
     * @param int $id ID
     * @return array 信息
     */
    public function getInfo($id)
    {
        $map = array();
        $map['id'] = $id;
        $info = $this->getWhereInfo($map);
        if(empty($info)){
            $this->error = '素材不存在！';
        }
        return $info;
    }

    /**
     * 获取信息
     * @param array $where 条件
     * @return array 信息
     */
    public function getWhereInfo($where,$order = '')
    {
        $info = $this->where($where)
                    ->order($order)
                    ->find();
        return $info;
    }
    /**
     * 删除信息
     * @param int $id ID
     * @return bool 删除状态
     */
    public function delData($id)
    {
        $map = array();
        $map['id'] = $id;
        $status = $this->where($map)->delete();
        return $status;
    }
}
