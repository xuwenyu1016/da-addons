<?php
namespace app\wechat\model;
use app\base\model\BaseModel;
/**
 * 图文素材
 */
class WechatItemModel extends BaseModel {
    /**
     * 获取粉丝列表
     * @return array 列表
     */
    public function loadList($where = array(), $limit = 0, $order = 'id desc'){
        //获取最终结果
        $pageList = $this->field($field)
                    ->where($where)
                    ->order($order)
                    ->limit($limit)
                    ->select();
        return $pageList;
    }
    public function getReply($id)
    {
        $map = array();
        $data = array();
        $map['id'] = $id;
        $info = $this->where($map)->find();
        if(empty($info)){
            return '';
        }
        if ($info['type'] == 1) {
            $data['type'] = 'text';
            $data['content'] = $info['text'];
            return $data;
        }else{
            $data['type'] = 'news';
            $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
            $infos = array();
            $ids = explode(',', $info['text']);
            if ($info['type'] == 3) {
               $model = target('Wechatnews');
            }else{
               $model = target('article/ContentArticle');
            }
            foreach ($ids as $key => $value) {
                $one = $model->getInfo($value);
                if (strpos('http', $one['image'])) {
                    $image = $one['image'];
                }else{
                    $image = $http_type.$_SERVER['SERVER_NAME'].$one['image'];
                }
                $url = $this->getUrl($one);
                $infos[$key]['Title'] = $one['title'];
                $infos[$key]['Description'] = $one['description'];
                $infos[$key]['PicUrl'] = $image;
                $infos[$key]['Url'] = $url;
            }

            $data['item'] = $infos;
            return $data;
        }
    }
    /**
     * 更新信息
     * @param string $type 更新类型
     * @param array $data 更新数据
     * @return bool 更新状态
     */
    public function saveData($type = 'add'){
        $data = $this->create();
        if(!$data){
            return false;
        }
        if($type == 'add'){
            if (in_array($data['type'], array('3','2'))) {
                $data['text'] = implode(',', $data['text']);
            }
            return $this->add($data);
        }
        if($type == 'edit'){
            if(empty($data['id'])){
                return false;
            }
            if (in_array($data['type'], array('3','2'))) {
                $data['text'] = implode(',', $data['text']);
            }
            $where = array();
            $where['id'] = $data['id'];
            $status = $this->where($where)->save($data);
            if($status === false){
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 获取信息
     * @param int $id ID
     * @return array 信息
     */
    public function getInfo($id)
    {
        $map = array();
        $map['id'] = $id;
        $info = $this->getWhereInfo($map);
        if(empty($info)){
            $this->error = '素材不存在！';
        }
        return $info;
    }

    /**
     * 获取信息
     * @param array $where 条件
     * @return array 信息
     */
    public function getWhereInfo($where,$order = '')
    {
        $info = $this->where($where)
                    ->order($order)
                    ->find();
        return $info;
    }
    /**
     * 删除信息
     * @param int $id ID
     * @return bool 删除状态
     */
    public function delData($id)
    {
        $map = array();
        $map['id'] = $id;
        $status = $this->where($map)->delete();
        return $status;
    }
    /**
     * 字段HTML
     * @param array $config 字段配置
     * @return string HTML信息
     */
    public function htmlFieldFull($type,$content)
    {
        switch ($type) {
            case '1'://文本回复
                $html = '
                    <textarea class="input" id="text" name="text" rows="10" cols="62">'.$content.'</textarea>
                ';
                break;
            case '2'://站内文章
                $listIds = explode(',', $content);
                $html = '<div id="items" class="line-middle">';
                foreach ($listIds as $key => $value) {
                    $info = target('article/ContentArticle')->getInfo($value);
                    if (empty($info)) {
                        continue;
                    }
                    $html .= '<div class="xl12 xs6 xm4 xb3" id="'.$info['content_id'].'">
                        <span class="close rotate-hover"></span>
                        <div class="media padding-bottom clearfix">
                            <a href="#">
                                <img src="'.$info['image'].'" class="radius img-responsive">
                            </a>
                            <div class="media-body">
                                <strong>'.$info['title'].'</strong>
                            </div>
                        </div>
                    <input type="hidden" name="text[]" value="'.$info['content_id'].'"></div>';
                }
                $html .='</div><a class="button bg-blue button-big" data="text" data-action="article" id="content_add" href="javascript:;" ><span class="icon-plus"> 添加</span></a>';

                break;
            case '3'://图文素材
                $listIds = explode(',', $content);
                $html = '<div id="items" class="line-middle">';
                foreach ($listIds as $key => $value) {
                    $info = target('wechat/WechatNews')->getInfo($value);
                    if (empty($info)) {
                        continue;
                    }
                    $html .= '<div class="xl12 xs6 xm4 xb3" id="'.$info['id'].'">
                        <span class="close rotate-hover"></span>
                        <div class="media padding-bottom clearfix">
                            <a href="#">
                                <img src="'.$info['image'].'" class="radius img-responsive">
                            </a>
                            <div class="media-body">
                                <strong>'.$info['title'].'</strong>
                            </div>
                        </div>
                    <input type="hidden" name="text[]" value="'.$info['id'].'"></div>';
                }
                $html .='</div><a class="button bg-blue button-big" data="text" data-action="news" id="content_add" href="javascript:;" ><span class="icon-plus"> 添加</span></a>';
                break;
        }
        return $html;
    }
    public function getUrl($info)
    {
       if (!empty($info['app'])) {
           return match_url(strtolower($info['app']).'/Content/index',array('content_id'=>$info['content_id'],'urltitle'=>$info['urltitle'],'class_urlname'=>$info['class_urlname']));
       }else{
          return match_url('wechat/Connect/view',array('id'=>$info['id']));
       }
    }
}
