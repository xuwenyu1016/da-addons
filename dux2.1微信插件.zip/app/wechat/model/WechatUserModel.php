<?php
namespace app\wechat\model;
use app\base\model\BaseModel;
/**
 * 微信粉丝操作
 */
class WechatUserModel extends BaseModel {

    /**
     * 获取粉丝列表
     * @return array 列表
     */
    public function loadList($where = array(), $limit = 0, $order = 'we_id desc,subscribe_time desc'){
        //获取最终结果
        $pageList = $this->field($field)
                    ->where($where)
                    ->order($order)
                    ->limit($limit)
                    ->select();
        return $pageList;
    }
    /**
     * 取消关注
     * @param  [type] $openid [openid]
     * @return [type]         [status]
     */
    public function unsubscribe($openid)
    {
        $map = array();
        $map['openid'] = $openid;
        $data = array();
        $data['subscribe'] = 0;
        return $this->where($map)->save($data);
    }

    /**
     * 同步粉丝
     * @param string $type 更新类型
     * @return bool 更新状态
     */
    public function saveUsers($data = array()){
        if(!$data){
            return false;
        }
        if ($this->checkHas($data['openid'])) {
            $type = 'edit';
        }else{
            $type = 'add';
        }
        if ($type == 'add') {
            $data['tagid_list'] = serialize($data['tagid_list']);
            $sataus = $this->add($data);
            if (!$sataus) {
                $this->error = '粉丝获取失败';
                return false;
            }else{
                return true;
            }
        }
        if ($type == 'edit') {
            $where = array();
            $where['openid'] = $data['openid'];
            $status = $this->where($where)->save($data);
            if($status === false){
                return false;
            }
            return true;
        }
        return false;
    }

    public function checkHas($openid)
    {
        $map = array();
        $map['openid'] = $openid;
        $info = $this->where($map)->find();
        if(empty($info)){
            return false;
        }
        return true;
    }

    /**
     * 获取信息
     * @param int $openid ID
     * @return array 信息
     */
    public function getInfo($openid)
    {
        $map = array();
        $map['openid'] = $openid;
        $info = $this->getWhereInfo($map);
        if(empty($info)){
            $this->error = '粉丝不存在！';
        }
        return $info;
    }

    /**
     * 获取信息
     * @param array $where 条件
     * @return array 信息
     */
    public function getWhereInfo($where,$order = '')
    {
        $info = $this->where($where)
                    ->order($order)
                    ->find();
        return $info;
    }
    /**
     * 删除信息
     * @param int $we_id ID
     * @return bool 删除状态
     */
    public function delData($we_id)
    {
        $map = array();
        $map['we_id'] = $we_id;
        $status = $this->where($map)->delete();
        return $status;
    }
}
