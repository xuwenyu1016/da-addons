<?php
namespace app\wechat\model;
use app\base\model\BaseModel;
/**
 * 微信在自定义菜单
 */
class WechatMenuModel extends BaseModel {

    /**
     * 获取粉丝列表
     * @return array 列表
     */
    public function loadList($where = array(), $id = 0){
        $data = $this->loadData($where);
        $cat = new \framework\ext\Category(array('id', 'parent_id', 'name', 'cname'));
        $data = $cat->getTree($data, intval($id));
        return $data;
    }
    /**
     * 获取列表
     * @return array 列表
     */
    public function loadData($where = array(), $limit = 0){
        $pageList = $this->where($where)
                    ->limit($limit)
                    ->order("ordering ASC , id ASC")
                    ->select();
        return $pageList;
    }
    /**
     * 统计指定栏目菜单个数
     */
    public function countList($where)
    {
        return $this->where($where)->count();
    }
    /**
     * 获取列表
     * @return array 列表
     */
    public function getMenu(){
        $where = array();
        $where['parent_id'] = 0;
        $parent = $this->loadData($where);
        $menu = array();
        $sub_button = array();
        $i = 0;
        foreach ($parent as $k => $v) {
            $menu[$i]['name'] = $v['name'];
            $sub = $this->loadList(array(),$v['id']);
            $k=0;
            foreach ($sub as $key => $value) {
                $type = $value['type'] == 1?'click':'view';
                $url = $value['type'] == 1?'key':'url';
                $sub_button[$k]['type'] =$type;
                $sub_button[$k]['name'] =$value['name'];
                $sub_button[$k][$url] =$value['key'];
                $k++;
            }
            $menu[$i]['sub_button'] = $sub_button;
            unset($sub_button);
            $i++;
        }
        return $menu;
    }

    /**
     * 更新信息
     * @param string $type 更新类型
     * @param array $data 更新数据
     * @return bool 更新状态
     */
    public function saveData($type = 'add'){
        $data = $this->create();
        if(!$data){
            return false;
        }
        if($type == 'add'){
            return $this->add($data);
        }
        if($type == 'edit'){
            if(empty($data['id'])){
                return false;
            }
            $where = array();
            $where['id'] = $data['id'];
            $status = $this->where($where)->save($data);
            if($status === false){
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 获取信息
     * @param int $id ID
     * @return array 信息
     */
    public function getInfo($id)
    {
        $map = array();
        $map['id'] = $id;
        $info = $this->getWhereInfo($map);
        if(empty($info)){
            $this->error = '菜单不存在！';
        }
        return $info;
    }

    /**
     * 获取信息
     * @param array $where 条件
     * @return array 信息
     */
    public function getWhereInfo($where,$order = '')
    {
        $info = $this->where($where)
                    ->order($order)
                    ->find();
        return $info;
    }
    /**
     * 删除信息
     * @param int $id ID
     * @return bool 删除状态
     */
    public function delData($id)
    {
        $map = array();
        $map['id'] = $id;
        $status = $this->where($map)->delete();
        return $status;
    }
}
