<?php
return array (
  'appid'=>'',
  'secret'=>'',
  'token'=>'',
  'EncodingAESKey'=>'',
  'msg_welcome'=>'欢迎你关注我们！',
  'msg_default'=>'我好像不明白你在说什么。。。',
);