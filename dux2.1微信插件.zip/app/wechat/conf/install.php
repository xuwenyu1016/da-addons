<?php
return array(
	'INSTALL_SQL'=>"
	CREATE TABLE IF NOT EXISTS `{pre}wechat_item` (
	  `id` int(10) NOT NULL AUTO_INCREMENT,
	  `title` varchar(255) NOT NULL,
	  `ordering` int(10) NOT NULL,
	  `keywords` varchar(255) NOT NULL,
	  `match` int(10) NOT NULL,
	  `type` int(10) NOT NULL,
	  `text` text NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	<@>
	CREATE TABLE IF NOT EXISTS `{pre}wechat_menu` (
	  `id` int(10) NOT NULL AUTO_INCREMENT,
	  `parent_id` int(10) NOT NULL,
	  `type` int(10) NOT NULL,
	  `key` varchar(255) NOT NULL,
	  `ordering` int(10) NOT NULL,
	  `name` varchar(255) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	<@>
	CREATE TABLE IF NOT EXISTS `{pre}wechat_news` (
	  `id` int(10) NOT NULL AUTO_INCREMENT,
	  `title` varchar(255) NOT NULL,
	  `author` varchar(255) NOT NULL,
	  `image` varchar(255) NOT NULL,
	  `content` text NOT NULL,
	  `description` varchar(255) NOT NULL,
	  `linkurl` varchar(255) NOT NULL,
	  `time` int(11) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	<@>
	CREATE TABLE IF NOT EXISTS `{pre}wechat_user` (
	  `we_id` int(10) NOT NULL AUTO_INCREMENT,
	  `user_id` int(10) DEFAULT NULL,
	  `openid` varchar(250) NOT NULL,
	  `nickname` varchar(255) NOT NULL,
	  `headimgurl` varchar(255) NOT NULL,
	  `subscribe_time` int(11) NOT NULL,
	  `subscribe` int(10) NOT NULL,
	  `sex` int(10) NOT NULL,
	  `city` varchar(255) NOT NULL,
	  `province` varchar(255) NOT NULL,
	  `country` varchar(255) NOT NULL,
	  `remark` varchar(255) NOT NULL,
	  `groupid` int(10) NOT NULL,
	  `language` varchar(255) NOT NULL,
	  `tagid_list` varchar(255) NOT NULL,
	  PRIMARY KEY (`we_id`)
	) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
",
	'UNSTALL_SQL'=>'
		DROP TABLE `{pre}wechat_item`;<@>
		DROP TABLE `{pre}wechat_menu`;<@>
		DROP TABLE `{pre}wechat_news`;<@>
		DROP TABLE `{pre}wechat_user`;
	',
	'APP_SQL_PRE'=>'dux_',
);