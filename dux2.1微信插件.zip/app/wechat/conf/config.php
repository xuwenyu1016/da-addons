<?php
return array (
  'APP_STATE'=>0,
  'APP_INSTALL'=>0,
  'APP_NAME' => '微信插件',
);