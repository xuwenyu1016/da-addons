<?php
namespace app\wechat\controller;
use app\home\controller\SiteController;
use app\wechat\controller\WechatController as wechat;
/**
 * 微信连接
 */

class ConnectController extends SiteController {
    public function __construct()
    {
        $this->model = new wechat();
        $this->config = load_config('wechat');
    }

    public function index(){
        $wechat = $this->model->load_wechat('Receive');

        if ($wechat->valid() === FALSE) {
             $this->log($wechat->errMsg);
             exit($wechat->errMsg);
         }
        $openid = $wechat->getRev()->getRevFrom();
        /* 分别执行对应类型的操作 */
        switch ($wechat->getRev()->getRevType()) {
            case 'text':
            	$keys = $wechat->getRevContent();
                $data = $this->_keys($keys);
                if (empty($data)) {
                    return '';
                }
                break;
            case 'event':
            	$event = $wechat->getRevEvent();
                if ($event['event'] == 'subscribe') {
                    return $wechat->text($this->config['msg_welcome'])->reply();
                }
                if ($event['event'] == 'unsubscribe') {
                   target('wechat/WechatUser')->unsubscribe($openid);
                   exit('sucess');
                }
                if ($event['event'] == 'CLICK') {
                    $data = $this->_keys($event['key']);
                }
                break;
        }
        if (empty($data)) {
            return $wechat->text($this->config['msg_default'])->reply();
        }
        if ($data['type'] == 'text') {
            return $wechat->text($data['content'])->reply();
        }else{
            return $wechat->news($data['item'])->reply();
        }
    }

    protected function _keys($msg){
        $wechat = $this->model->load_wechat('Receive');
        $list = target('wechat/wechatItem')->loadList();
        $exactList = array();
        $fuzzyList = array();
        $type = '';
        $replyId = 0;
        foreach ($list as $vo) {
            if ($vo['type']) {
                $exactList[] = $vo;
            } else {
                $fuzzyList[] = $vo;
            }
        }
        foreach ($list as $vo) {
            $keywords = explode(',', $vo['keywords']);
            if (in_array($msg, $keywords)) {
                $replyId = $vo['id'];
                break;
            }
        }
        foreach ($fuzzyList as $vo) {
            $keywords = explode(',', $vo['keywords']);
            foreach ($keywords as $v) {
                if (strpos($msg, $v) !== false) {
                    $replyId = $vo['id'];
                    break 2;
                }
            }
        }
        if (!$replyId) {
            return '';
        }
        $info = target('wechat/wechatItem')->getReply($replyId);
        if (empty($info)) {
            return '';
        }
        //$data = null;
        return $info;
    }

    public function view()
    {
    	$id = request('get.id',0,'intval');
        if (empty($id)) {
            $this->error404();
        }
        $model = target('wechat/WechatNews');
        //获取内容信息
        if(!empty($id)){
            $contentInfo=$model->getInfo($id);
        }else{
            $this->error404();
        }

        //内容处理
        $contentInfo['content'] = html_out($contentInfo['content']);

        //MEDIA信息
        $media = $this->getMedia($contentInfo['title'],$contentInfo['keywords'],$contentInfo['description']);
        //模板赋值
        $this->assign('contentInfo', $contentInfo);
        $this->assign('media', $media);
        $this->siteDisplay('wechat');
    }
    protected function log( $logthis ){
        file_put_contents('logfile.log', date("Y-m-d H:i:s"). " " . $logthis.PHP_EOL, FILE_APPEND | LOCK_EX);
    }

}

