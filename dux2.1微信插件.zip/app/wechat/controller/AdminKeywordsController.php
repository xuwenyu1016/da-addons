<?php
namespace app\wechat\controller;
use app\admin\controller\AdminController;
use app\wechat\controller\WechatController as wechat;
/**
 * 关键字回复
 */
class AdminKeywordsController extends AdminController {
    /**
     * 当前模块参数
     */
    protected function _infoModule(){

        return array(
            'info'  => array(
                'name' => '关键字回复',
                'description' => '微信关键字触发内容',
            ),
            'menu' => array(
                    array(
                        'name' => '关键字回复',
                        'url' => url('index'),
                        'icon' => 'list',
                    ),
            ),
            'add' => array(
                    array(
                        'name' => '添加关键字',
                        'url' => url('add'),
                        'icon' => 'plus',
                ),
            )
        );
    }

    /**
     * 自定义菜单
     */
    public function index(){
        //筛选条件
        $where = array();
        $keyword = request('request.keyword','');
        $status = request('request.type',0,'intval');
        if(!empty($keyword)){
            $where[] = 'title like "%'.$keyword.'%" or keywords like "%'.$keyword.'%"';
        }
        if(!empty($status)){
            switch ($status) {
                case '1':
                    $where['type'] = 1;
                    break;
                case '2':
                    $where['type'] = 2;
                    break;
                case '3':
                    $where['type'] = 3;
                    break;
            }
        }
        //URL参数
        $pageMaps = array();
        $pageMaps['keyword'] = $keyword;
        $pageMaps['type'] = $status;
        //查询数据
        $list = target('WechatItem')->page(30)->loadList($where,$limit);
        $this->pager = target('WechatItem')->pager;
        //位置导航
        $breadCrumb = array('自定义菜单'=>url());
        //模板传值
        $this->assign('breadCrumb',$breadCrumb);
        $this->assign('list',$list);
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay();
    }
    /*
     * 添加图文素材
     */
    public function add(){
        if(!IS_POST){
            $breadCrumb = array('图文素材'=>url('index'),'添加图文素材'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->adminDisplay('info');
        }else{
            if(target('WechatItem')->saveData('add')){
                $this->success('添加成功！',url('index'));
            }else{
                $msg = target('WechatItem')->getError();
                if(empty($msg)){
                    $this->error('添加失败');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /*
     * 添加菜单
     */
    public function edit(){
        if(!IS_POST){
            $Id = request('get.id','','intval');
            if(empty($Id)){
                $this->error('参数不能为空！');
            }
            //获取记录
            $model = target('WechatItem');
            $info = $model->getInfo($Id);
            if(!$info){
                $this->error($model->getError());
            }
            $breadCrumb = array('关键字回复'=>url('index'),'添加关键字'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->assign('info',$info);
            $this->adminDisplay('info');
        }else{
            if(target('WechatItem')->saveData('edit')){
                $this->success('修改成功！',url('index'));
            }else{
                $msg = target('WechatItem')->getError();
                if(empty($msg)){
                    $this->error('修改失败');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /**
     * 删除
     */
    public function del(){
        $id = request('post.data');
        if(empty($id)){
            $this->error('参数不能为空！');
        }
        //删除栏目操作
        if(target('WechatItem')->delData($id)){
            $this->success('删除成功！');
        }else{
            $msg = target('WechatItem')->getError();
            if(empty($msg)){
                $this->error('删除失败！');
            }else{
                $this->error($msg);
            }
        }
    }
    /**
     * 批量操作
     */
    public function batchAction(){
        $type = request('post.type',0,'intval');
        $ids = request('post.ids');
        if(empty($type)){
            $this->error('请选择操作！');
        }
        if(empty($ids)){
            $this->error('请先选择操作项目！');
        }
        foreach ($ids as $id) {
            $data = array();
            $data['id'] = $id;
            switch ($type) {

                case 4:
                    //删除
                    target('WechatItem')->delData($id);
                    break;
            }
        }
        $this->success('批量操作执行完毕！');

    }

    /**
     * 动态获取
     */
    public function getField()
    {
        $type = request('post.type');
        $id = request('post.id');
        $fieldModel = target('WechatItem');
        $info = $fieldModel->getInfo($id);
        if (empty($type)) {
           $type = $info['type'];
        }
        $html = $fieldModel->htmlFieldFull($type,$info['text']);
        $this->show($html);
    }
    /**
     * 获取站内文章
     */
    public function getarticle()
    {
        $list = target('article/ContentArticle')->loadList();
    }
    /**
     * 获取图文素材
     */
    public function news()
    {
        $where = array();
        //查询数据
        $list = target('Wechatnews')->page(10)->loadList($where,$limit);
        $this->pager = target('Wechatnews')->pager;
        //模板传值
        $this->assign('list',$list);
        $this->assign('action','news');
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay('action');
    }
    /**
     * 获取图文素材
     */
    public function article()
    {
        $where = array();
        //查询数据
        $list = target('article/ContentArticle')->page(10)->loadList($where,$limit);
        $this->pager = target('article/ContentArticle')->pager;
        //模板传值
        $this->assign('list',$list);
        $this->assign('action','article');
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay('action');
    }
    /**
     * 获取单条信息
     */
    public function views()
    {
        $action = request('request.action','');
        $id = request('request.id','');
        if ($action == 'news') {
           $model = target('Wechatnews');
        }else{
           $model = target('article/ContentArticle');
        }
        $info = $model->getInfo($id);
        $this->ajaxReturn($info);
    }
}

