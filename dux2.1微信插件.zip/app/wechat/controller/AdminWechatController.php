<?php
namespace app\wechat\controller;
use app\admin\controller\AdminController;
use app\wechat\controller\WechatController as wechat;
/**
 * 微信管理
 */
class AdminWechatController extends AdminController {
    /**
     * 当前模块参数
     */
    protected function _infoModule(){
        $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
        return array(
            'info'  => array(
                'name' => '微信设置',
                'description' => '绑定微信接口',
                'url' => $http_type.$_SERVER['SERVER_NAME'].'/index.php?r=wechat/Connect/index'
            ),
        );
    }

    /**
     * 绑定
     */
    public function index(){
        if(!IS_POST){
            $breadCrumb = array('微信设置'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('info',load_config('wechat'));
            $this->adminDisplay();
        }else{
            if(save_config('wechat', $_POST)){
                $this->success('微信设置成功',url('wechat/AdminWechat/users'));
            }else{
                $this->error('微信设置失败');
            }
        }
    }

    /**
     * 粉丝列表
     */
    public function users(){
        //筛选条件
        $where = array();
        $keyword = request('request.keyword','');
        $status = request('request.subscribe',0,'intval');
        if(!empty($keyword)){
            $where[] = 'nickname like "%'.$keyword.'%" or openid ="'.$keyword.'"';
        }
        if(!empty($status)){
            switch ($status) {
                case '1':
                    $where['subscribe'] = 1;
                    break;
                case '2':
                    $where['subscribe'] = 0;
                    break;
            }
        }
        //URL参数
        $pageMaps = array();
        $pageMaps['keyword'] = $keyword;
        $pageMaps['subscribe'] = $status;
        //查询数据
        $list = target('WechatUser')->page(30)->loadList($where,$limit);
        $this->pager = target('WechatUser')->pager;
        //位置导航
        $breadCrumb = array('粉丝列表'=>url());
        //模板传值
        $this->assign('breadCrumb',$breadCrumb);
        $this->assign('list',$list);
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay();
    }
    /*
     * 同步粉丝
     */
    public function getusers()
    {
        $wechat = new wechat();
        $user = $wechat->load_wechat('User');
        $result = $user->getUserList($openid);
        if($result===FALSE){
            $this->error($wechat->errorCode[$user->errCode]);
        }else{
            $users = $result['data']['openid'];
            foreach ($users as $key => $value) {
                $data = $user->getUserInfo($value);
                target('WechatUser')->saveUsers($data);
            }
            $this->success('粉丝同步成功！',url('wechat/AdminWechat/users'));
        }
    }
    /*
     * 更新粉丝信息
     */
    public function update()
    {
        $openid = request('get.openid');
        $wechat = new wechat();
        $user = $wechat->load_wechat('User');
        $result = $user->getUserList($openid);
        if($result===FALSE){
            $this->error($wechat->errorCode[$user->errCode]);
        }else{
            $data = $user->getUserInfo($openid);
            if (target('WechatUser')->saveUsers($data)) {
               $this->success('粉丝更新成功！',url('wechat/AdminWechat/users'));
            }else{
                $this->error('粉丝更新失败');
            }

        }
    }
    /*
     * 更新粉丝信息
     */
    public function edit()
    {
        if(!IS_POST){
            $openid = request('get.openid');
            if(empty($openid)){
                $this->error('参数不能为空！');
            }
            //获取记录
            $model = target('WechatUser');
            $info = $model->getInfo($openid);
            if(!$info){
                $this->error($model->getError());
            }
            $breadCrumb = array('粉丝列表'=>url('index'),'粉丝标签修改'=>url('',array('openid'=>$openid)));
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','修改');
            $this->assign('info',$info);
            $this->adminDisplay('info');
        }else{
            $remark = request('post.remark');
            $openid = request('post.openid');
            if (empty($remark)) {
                $this->error('标签不能为空！');
            }
            $wechat = new wechat();
            $user = $wechat->load_wechat('User');
            $result = $user->updateUserRemark($openid,$remark);
            if($result===FALSE){
                $this->error($wechat->errorCode[$user->errCode]);
            }else{
                $user = $wechat->load_wechat('User');
                $result = $user->getUserList($openid);
                $data = $user->getUserInfo($openid);
                if (target('WechatUser')->saveUsers($data)) {
                   $this->success('粉丝标签更新成功！',url('wechat/AdminWechat/users'));
                }else{
                    $this->error('粉丝标签更新失败');
                }
            }
        }
    }
    /**
     * 删除
     */
    public function del(){
        $we_id = request('post.data');
        if(empty($we_id)){
            $this->error('参数不能为空！');
        }
        //删除页面操作
        $model = target('WechatUser');
        if($model->delData($we_id)){
            $this->success('粉丝删除成功！');
        }else{
            $msg = $model->getError();
            if(empty($msg)){
                $this->error('粉丝删除失败！');
            }else{
                $this->error($msg);
            }
        }
    }
    /**
     * 批量操作
     */
    public function batchAction(){
        $type = request('post.type',0,'intval');
        $ids = request('post.ids');
        if(empty($type)){
            $this->error('请选择操作！');
        }
        if(empty($ids)){
            $this->error('请先选择操作项目！');
        }
        foreach ($ids as $id) {
            $data = array();
            $data['we_id'] = $id;
            switch ($type) {

                case 4:
                    //删除
                    target('WechatUser')->delData($id);
                    break;
            }
        }
        $this->success('批量操作执行完毕！');

    }

}

