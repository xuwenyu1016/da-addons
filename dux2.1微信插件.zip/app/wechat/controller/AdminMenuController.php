<?php
namespace app\wechat\controller;
use app\admin\controller\AdminController;
use app\wechat\controller\WechatController as wechat;
/**
 * 微信自定义菜单
 */
class AdminMenuController extends AdminController {
    /**
     * 当前模块参数
     */
    protected function _infoModule(){

        return array(
            'info'  => array(
                'name' => '自定义菜单',
                'description' => '设置公众号自定义菜单',
            ),
            'menu' => array(
                    array(
                        'name' => '自定义菜单',
                        'url' => url('index'),
                        'icon' => 'list',
                    ),
                    array(
                        'name' => '发布菜单',
                        'url' => url('postmenu'),
                        'icon' => 'list',
                    ),
                    array(
                        'name' => '拉取菜单',
                        'url' => url('getmenu'),
                        'icon' => 'list',
                    ),
            ),
            'add' => array(
                    array(
                        'name' => '添加菜单',
                        'url' => url('add'),
                        'icon' => 'plus',
                ),
            )
        );
    }

    /**
     * 自定义菜单
     */
    public function index(){
        //筛选条件
        $where = array();
        $keyword = request('request.keyword','');
        $status = request('request.subscribe',0,'intval');
        if(!empty($keyword)){
            $where[] = 'nickname like "%'.$keyword.'%" or openid ="'.$keyword.'"';
        }
        if(!empty($status)){
            switch ($status) {
                case '1':
                    $where['subscribe'] = 1;
                    break;
                case '2':
                    $where['subscribe'] = 0;
                    break;
            }
        }
        //URL参数
        $pageMaps = array();
        $pageMaps['keyword'] = $keyword;
        $pageMaps['subscribe'] = $status;
        //查询数据
        $list = target('WechatMenu')->page(30)->loadList($where,$limit);
        $this->pager = target('WechatMenu')->pager;
        //位置导航
        $breadCrumb = array('自定义菜单'=>url());
        //模板传值
        $this->assign('breadCrumb',$breadCrumb);
        $this->assign('list',$list);
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay();
    }

    /*
     * 添加菜单
     */
    public function add(){
        if(!IS_POST){
            $breadCrumb = array('自定义菜单'=>url('index'),'添加自定义菜单'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->assign('menuList',target('WechatMenu')->loadList());
            $this->adminDisplay('info');
        }else{
            $id = request('post.parent_id');
            if ($this->count($id) ==3 && $id == false) {
                 $this->error('顶级栏目不能超过3条');
            }
            if ($this->count($id) == 5 && $id==true) {
                $this->error('二级栏目不能超过5条');
            }
            if(target('WechatMenu')->saveData('add')){
                $this->success('添加成功！',url('index'));
            }else{
                $msg = target('WechatMenu')->getError();
                if(empty($msg)){
                    $this->error('添加失败');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /*
     * 添加菜单
     */
    public function edit(){
        if(!IS_POST){
            $Id = request('get.id','','intval');
            if(empty($Id)){
                $this->error('参数不能为空！');
            }
            //获取记录
            $model = target('WechatMenu');
            $info = $model->getInfo($Id);
            if(!$info){
                $this->error($model->getError());
            }
            $breadCrumb = array('自定义菜单'=>url('index'),'添加自定义菜单'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->assign('info',$info);
            $this->assign('menuList',target('WechatMenu')->loadList());
            $this->adminDisplay('info');
        }else{
            if(target('WechatMenu')->saveData('edit')){
                $this->success('修改成功！',url('index'));
            }else{
                $msg = target('WechatMenu')->getError();
                if(empty($msg)){
                    $this->error('修改成功！');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /*
     * 发布菜单
     */
    public function postmenu()
    {
        $wechat = new wechat();
        $menu = $wechat->load_wechat('menu');
        $data = target('WechatMenu')->getMenu();
        $list = array();
        $list['button'] = $data;
        $result = $menu->createMenu($list);
        if($result===FALSE){
            $this->error($wechat->errorCode[$user->errCode]);
        }else{
            $this->success('菜单发布成功',url('index'));
        }
    }
    /*
     * 拉取菜单
     */
    public function getmenu()
    {
        if(target('WechatMenu')->loadList()){
            $this->error('请先清空现有的菜单再进行拉取操作！');
        }
        $wechat = new wechat();
        $menu = $wechat->load_wechat('menu');
        $result = $menu->getMenu();
        if($result===FALSE){
            $this->error($wechat->errorCode[$user->errCode]);
        }else{
            $menu = $result['menu']['button'];
            $data = array();
            $sub = array();
            foreach ($menu as $key => $value) {
                $data['parent_id'] = 0;
                $data['name'] = $value['name'];
                $data['ordering'] = $key;
                $_POST = $data;
                $id = target('WechatMenu')->saveData('add');
                foreach ($value['sub_button'] as $k => $v) {
                    unset($_POST);
                    unset($sub);
                    $type = $v['type']=='view'?2:1;
                    $url = empty($v['url'])?$v['key']:$v['url'];
                    $sub['parent_id'] = $id;
                    $sub['name'] = $v['name'];
                    $sub['type'] = $type;
                    $sub['ordering'] = $k;
                    $sub['key'] = $url;
                    $_POST = $sub;
                    target('WechatMenu')->saveData('add');
                }
            }
            $this->success('菜单获取成功',url('index'));
        }
    }
    /**
     * 删除
     */
    public function del(){
        $id = request('post.data');
        if(empty($id)){
            $this->error('参数不能为空！');
        }
        //判断子栏目
        if(target('WechatMenu')->loadList(array(), $id)){
            $this->error('请先删除子菜单！');
        }
        //删除栏目操作
        if(target('WechatMenu')->delData($id)){
            $this->success('菜单删除成功！');
        }else{
            $msg = target('WechatMenu')->getError();
            if(empty($msg)){
                $this->error('菜单删除失败！');
            }else{
                $this->error($msg);
            }
        }
    }
    /**
     * 统计数量
     */
    public function count($data)
    {
       $where = array();
       $where['parent_id'] = $data;
       $num = target('WechatMenu')->countList($where);
       return $num;
    }
}

