<?php
namespace app\wechat\controller;
use app\admin\controller\AdminController;
use app\wechat\controller\WechatController as wechat;
/**
 * 微信回复
 */
class AdminReplyController extends AdminController {
    /**
     * 当前模块参数
     */
    protected function _infoModule(){

        return array(
            'info'  => array(
                'name' => '自动回复',
                'description' => '管理微信自动回复内容',
            ),
            'menu' => array(
                    array(
                        'name' => '图文素材',
                        'url' => url('index'),
                        'icon' => 'list',
                    ),
            ),
            'add' => array(
                    array(
                        'name' => '添加图文素材',
                        'url' => url('add'),
                        'icon' => 'plus',
                ),
            )
        );
    }

    /**
     * 自定义菜单
     */
    public function index(){
        //筛选条件
        $where = array();
        $keyword = request('request.keyword','');
        $status = request('request.subscribe',0,'intval');
        if(!empty($keyword)){
            $where[] = 'nickname like "%'.$keyword.'%" or openid ="'.$keyword.'"';
        }
        if(!empty($status)){
            switch ($status) {
                case '1':
                    $where['subscribe'] = 1;
                    break;
                case '2':
                    $where['subscribe'] = 0;
                    break;
            }
        }
        //URL参数
        $pageMaps = array();
        $pageMaps['keyword'] = $keyword;
        $pageMaps['subscribe'] = $status;
        //查询数据
        $list = target('WechatNews')->page(30)->loadList($where,$limit);
        $this->pager = target('WechatNews')->pager;
        //位置导航
        $breadCrumb = array('自定义菜单'=>url());
        //模板传值
        $this->assign('breadCrumb',$breadCrumb);
        $this->assign('list',$list);
        $this->assign('page',$this->getPageShow($pageMaps));
        $this->assign('pageMaps',$pageMaps);
        $this->adminDisplay();
    }
    /*
     * 添加图文素材
     */
    public function add(){
        if(!IS_POST){
            $breadCrumb = array('图文素材'=>url('index'),'添加图文素材'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->adminDisplay('info');
        }else{
            if(target('WechatNews')->saveData('add')){
                $this->success('添加成功！',url('index'));
            }else{
                $msg = target('WechatNews')->getError();
                if(empty($msg)){
                    $this->error('添加失败');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /*
     * 添加菜单
     */
    public function edit(){
        if(!IS_POST){
            $Id = request('get.id','','intval');
            if(empty($Id)){
                $this->error('参数不能为空！');
            }
            //获取记录
            $model = target('WechatNews');
            $info = $model->getInfo($Id);
            if(!$info){
                $this->error($model->getError());
            }
            $breadCrumb = array('图文素材'=>url('index'),'添加图文素材'=>url());
            $this->assign('breadCrumb',$breadCrumb);
            $this->assign('name','添加');
            $this->assign('info',$info);
            $this->adminDisplay('info');
        }else{
            if(target('WechatNews')->saveData('edit')){
                $this->success('修改成功！',url('index'));
            }else{
                $msg = target('WechatNews')->getError();
                if(empty($msg)){
                    $this->error('修改失败');
                }else{
                    $this->error($msg);
                }
            }
        }
    }
    /**
     * 删除
     */
    public function del(){
        $id = request('post.data');
        if(empty($id)){
            $this->error('参数不能为空！');
        }
        //删除栏目操作
        if(target('WechatNews')->delData($id)){
            $this->success('素材删除成功！');
        }else{
            $msg = target('WechatNews')->getError();
            if(empty($msg)){
                $this->error('素材删除失败！');
            }else{
                $this->error($msg);
            }
        }
    }
    /**
     * 批量操作
     */
    public function batchAction(){
        $type = request('post.type',0,'intval');
        $ids = request('post.ids');
        if(empty($type)){
            $this->error('请选择操作！');
        }
        if(empty($ids)){
            $this->error('请先选择操作项目！');
        }
        foreach ($ids as $id) {
            $data = array();
            $data['id'] = $id;
            switch ($type) {

                case 4:
                    //删除
                    target('WechatNews')->delData($id);
                    break;
            }
        }
        $this->success('批量操作执行完毕！');

    }
    /*
     * 拉取菜单
     */
    public function getnews()
    {
        $wechat = new wechat();
        $media = $wechat->load_wechat('Media');
        $result = $media->getForeverList('news', '0', '20');
        if($result===FALSE){
            $this->error($wechat->errorCode[$user->errCode]);
        }else{
            $menu = $result['item'];
            $data = array();
            $sub = array();
            $item_id = array();
            $num = 0;
            foreach ($menu as $key => $value) {
                $data['media_id'] = $value['media_id'];
                if (target('WechatItem')->hasMedia($value['media_id'])) {
                    $num++;
                    continue;
                }
                $data['update_time'] = $value['update_time'];
                foreach ($value['content']['news_item'] as $k => $v) {
                    unset($sub);
                    unset($_POST);
                    $sub['title'] = $v['title'];
                    $sub['author'] = $v['author'];
                    $sub['description'] = $v['digest'];
                    $sub['content'] = html_out($v['content']);
                    $sub['linkurl'] = $v['content_source_url'];
                    $sub['image'] = $v['thumb_url'];
                    $sub['time'] = date('Y-m-d H:i:s',$value['update_time']);
                    $_POST = $sub;
                    $item_id[] = target('WechatNews')->saveData('add');
                }
                $data['item_id'] = implode(',', $item_id);
                target('WechatItem')->saveData($data,'add');
                unset($item_id);
            }
            $this->success('获取成功,'.$num.'条已忽略',url('index'));
        }
    }

}

