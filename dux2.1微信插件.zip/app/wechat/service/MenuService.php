<?php
namespace app\wechat\service;
/**
 * 后台菜单接口
 */
class MenuService{
    /**
     * 获取菜单结构
     */
    public function getAdminMenu(){
        return array(
            'wechat' => array(
                'name' => '微信',
                'icon' => 'weixin',
                'order' => 4,
                'menu' => array(
                    array(
                        'name' => '绑定信息',
                        'icon' => 'random',
                        'url' => url('wechat/AdminWechat/index'),
                        'order' => 0
                    ),
                    array(
                        'name' => '粉丝管理',
                        'icon' => 'child',
                        'url' => url('wechat/AdminWechat/users'),
                        'order' => 1
                    ),
                    array(
                        'name' => '自定义菜单',
                        'icon' => 'sliders',
                        'url' => url('wechat/AdminMenu/index'),
                        'order' => 2
                    ),
                    array(
                        'name' => '图文素材',
                        'icon' => 'photo',
                        'url' => url('wechat/AdminReply/index'),
                        'order' => 3
                    ),
                    array(
                        'name' => '关键字回复',
                        'icon' => 'tags',
                        'url' => url('wechat/AdminKeywords/index'),
                        'order' => 4
                    ),
                    // array(
                    //     'name' => '支付参数',
                    //     'icon' => 'money',
                    //     'url' => url('wechat/AdminPay/index'),
                    //     'order' => 5
                    // ),
                )
            )
        );
    }

}
